#include <stdint.h>
#include "tm4c123gh6pm.h"
#include <stdio.h>


volatile uint32_t countdown_value = 10000;
volatile uint8_t running = 0;
volatile uint32_t seconds=0,minutes=0,hours=0, milliseconds = 0;

void SysTick_Init(void)
{
    NVIC_ST_CTRL_R = 0;                   // Disable SysTick during setup
    NVIC_ST_RELOAD_R = 16000 - 1;         // Set reload value for 1ms interrupts
    NVIC_ST_CURRENT_R = 0;                // Clear the current count
    NVIC_ST_CTRL_R = 0x00000007;          // Enable SysTick with clock and interrupts
}

void Buttons_Init(void)
{
    SYSCTL_RCGCGPIO_R |= 0x00000020;  // Enable clock for PortF
    GPIO_PORTF_LOCK_R = 0x4C4F434B;   // Unlock PortF
    GPIO_PORTF_CR_R |= 0x1F;           // Allow changes to all PortF pins
    GPIO_PORTF_DIR_R &= ~0x11;         // Set Pin 4 and Pin 0 as input
    GPIO_PORTF_PUR_R |= 0x11;          // Enable pull-up resistors for Pin 4 and Pin 0
    GPIO_PORTF_DEN_R |= 0x11;          // Enable digital function for Pin 4 and Pin 0
    GPIO_PORTF_IS_R &= ~0x11;          // Set Pin 4 and Pin 0 as edge-sensitive
    GPIO_PORTF_IBE_R &= ~0x11;         // Set Pin 4 and Pin 0 as not both edges
    GPIO_PORTF_IEV_R &= ~0x11;         // Set Pin 4 and Pin 0 as falling edge
    GPIO_PORTF_ICR_R = 0x11;           // Clear any prior interrupt
    GPIO_PORTF_IM_R |= 0x11;           // Enable interrupt for Pin 4 and Pin 0
    NVIC_EN0_R |= 0x40000000;          // Enable interrupt in NVIC (PortF)
}

void LED_Init(void)
{
    SYSCTL_RCGCGPIO_R |= 0x20;          // Enable clock for PortF
    GPIO_PORTF_DIR_R |= 0x0E;           // Set Pins 1, 2, and 3 as output
    GPIO_PORTF_DEN_R |= 0x0E;           // Enable digital function for Pins 1, 2, and 3
    GPIO_PORTF_DATA_R &= ~0x0E;         // Turn off all LEDs initially
}

void ControlLED(void)
{
    if (running)
    {
       GPIO_PORTF_DATA_R &= ~0x06;  // Turn off red  and blue LEDs
       GPIO_PORTF_DATA_R |= 0x08;   // Turn on green LED
    }
    else
    {
       GPIO_PORTF_DATA_R &= ~0x0A;  // Turn off green and blue LEDs
       GPIO_PORTF_DATA_R |= 0x02;   // Turn on red LED
    }
}

void GPIOF_Handler(void)
{
    GPIO_PORTF_ICR_R = 0x11;  // Acknowledge the interrupt

    if ((GPIO_PORTF_DATA_R & 0x01) == 0)
    {
        if (running)
        {
            running = 0;   // Stop the timer
        }
        else
        {
            running = 1;    // Start or resume the timer
        }
    }
    else if ((GPIO_PORTF_DATA_R & 0x10) == 0)
    {
        running = 0;
        countdown_value = 10000;  // Reset countdown value to seconds
    }

    ControlLED();
}


void SysTick_Handler(void)
{
    if (running && countdown_value > 0)
    {
        countdown_value--;  // Decrement the countdown value

        if (countdown_value == 0)
        {
            running = 0;    // Timer reached 0, stop the timer
        }
    }

    ControlLED();
}

void DisplayTime(void)
{
    //convert countdown_value to H:M:S format and display it
    milliseconds = countdown_value;
    hours = countdown_value / 3600000;
    minutes = (countdown_value % 3600000) / 60000;
    seconds = ((countdown_value % 3600000) % 60000) / 1000;
}
int main(void)
{
    SysTick_Init();
    Buttons_Init();
    LED_Init();

    while (1)
    {
       DisplayTime();
    }
}
